package com.example.android.imagecaptureservice;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.CheckResult;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    int cameraID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    ////// Unhide App Icon /////
    // PackageManager p = getPackageManager();
    // ComponentName componentName = new ComponentName(this,MainActivity.class);
    // p.setComponentEnabledSetting(componentName,PackageManager.COMPONENT_ENABLED_STATE_ENABLED,PackageManager.DONT_KILL_APP);

        Button btnstart = (Button)findViewById(R.id.btnstart);
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ImageService.class);
                intent.putExtra("CameraID",cameraID);
                startService(intent);
            }
        });

        Button btnstop = (Button)findViewById(R.id.btnstop);
        btnstop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ImageService.class);
                stopService(intent);
            }
        });

        final RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radgrp);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                int selectedID = radioGroup.getCheckedRadioButtonId();
                RadioButton radbtn = (RadioButton)findViewById(selectedID);

                switch (selectedID) {
                    case R.id.back:
                        cameraID = 0;
                        break;
                    case R.id.front:
                        cameraID = 1;
                        break;



                }
            }
        });

        ///// Hide App Icon ////
        //PackageManager p2 = getPackageManager();
        //ComponentName componentName2 = new ComponentName(this,MainActivity.class);
        //p.setComponentEnabledSetting(componentName2,PackageManager.COMPONENT_ENABLED_STATE_DISABLED,PackageManager.DONT_KILL_APP);

    }
}
