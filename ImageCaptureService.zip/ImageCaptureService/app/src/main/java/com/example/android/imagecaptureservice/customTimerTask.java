package com.example.android.imagecaptureservice;

/**
 * Created by windows7 on 10/30/2017.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.TimerTask;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

public class customTimerTask extends TimerTask {


    private Context context;
    private Handler mHandler = new Handler();

    public customTimerTask(Context con) {
        this.context = con;
    }



    @Override
    public void run() {
        new Thread(new Runnable() {

            public void run() {

                mHandler.post(new Runnable() {
                    public void run() {
                     //   Toast.makeText(context, "DISPLAY YOUR MESSAGE", Toast.LENGTH_SHORT).show();
//                        SurfaceTexture surfaceTexture = new SurfaceTexture(10);
//                        Camera camera = null;//Camera.open();
//                        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
//                        int cameraCount = Camera.getNumberOfCameras();
//                        for (int camIdx = 0; camIdx < cameraCount; camIdx++) {
//                            Camera.getCameraInfo(camIdx, cameraInfo);
//                            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
//                                camera = Camera.open(camIdx);
//                            }};
//                        camera.getParameters().setPreviewSize(1, 1);
//                        try {
//
//                            camera.setPreviewTexture(surfaceTexture);
//                            camera.startPreview();
//                            camera.takePicture(null,null,pictureCallback);
//                            camera.stopPreview();
//                            camera.release();
//
//
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }

                        PictureTaker pictureTaker = new PictureTaker(context);
                        pictureTaker.takePicture();


                    }
                });
            }
        }).start();

    }
//    Camera.PictureCallback mCall = new Camera.PictureCallback()
//    {
//
//        public void onPictureTaken(byte[] data, Camera camera)
//        {
//            //decode the data obtained by the camera into a Bitmap
//
//            FileOutputStream outStream = null;
//            try{
//                outStream = new FileOutputStream("/sdcard/Image.jpg");
//                outStream.write(data);
//                outStream.close();
//            } catch (FileNotFoundException e){
//                Log.d("CAMERA", e.getMessage());
//            } catch (IOException e){
//                Log.d("CAMERA", e.getMessage());
//            }
//
//        }
//    };

    private void takePhoto() {

    }
}
