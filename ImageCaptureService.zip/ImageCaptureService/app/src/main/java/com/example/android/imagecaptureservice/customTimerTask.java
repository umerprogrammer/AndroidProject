package com.example.android.imagecaptureservice;

/**
 * Created by windows7 on 10/30/2017.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.TimerTask;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

public class customTimerTask extends TimerTask {


    private Context context;
    private Handler mHandler = new Handler();
    private int cameraID =1 ;

    public customTimerTask(Context con,int cameraID) {
        this.context = con;
        this.cameraID = cameraID;
    }



    @Override
    public void run() {
        new Thread(new Runnable() {

            public void run() {

                mHandler.post(new Runnable() {
                    public void run() {

                        PictureTaker pictureTaker = new PictureTaker(context);
                        pictureTaker.takePicture(cameraID);

                    }
                });
            }
        }).start();

    }

}
