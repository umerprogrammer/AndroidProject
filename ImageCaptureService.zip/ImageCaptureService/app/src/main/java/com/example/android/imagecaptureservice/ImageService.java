package com.example.android.imagecaptureservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by windows7 on 10/30/2017.
 */

public class ImageService extends Service {

     Timer timer = new Timer();
    TimerTask timerTask ;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this,"Start Service",Toast.LENGTH_SHORT).show();
        int cameraID =Integer.valueOf( intent.getIntExtra("CameraID",1));
        timerTask = new customTimerTask(ImageService.this,cameraID);
        timer.scheduleAtFixedRate(timerTask,10000,10000);
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this,"Stop Service",Toast.LENGTH_SHORT).show();
        stopTimerTask();
    }

    public void stopTimerTask(){
        if(timer != null){
            timer.cancel();
            timer = null;
        }
    }
}
