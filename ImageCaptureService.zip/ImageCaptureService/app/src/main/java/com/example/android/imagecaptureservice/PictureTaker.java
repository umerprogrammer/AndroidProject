package com.example.android.imagecaptureservice;

import android.content.Context;
import android.hardware.Camera;
import android.util.Log;
import android.view.SurfaceView;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by windows7 on 10/31/2017.
 */

public class PictureTaker implements Camera.PictureCallback
{
    private Camera mCam;
    private Context context;

    public PictureTaker(Context context)
    {
        this.context = context;
    }

    public void takePicture()
    {
        try
        {
            mCam = Camera.open();
        }
        catch (Exception e)
        {
            System.out.println("Problem opening camera! " + e);
            return;
        }

        if (mCam == null)
        {
            System.out.println("Camera is null!");
            return;
        }

        try
        {
            SurfaceView view = new SurfaceView(context.getApplicationContext()) ;//MyApp.getPreviewSurface(); // my own fcn
            mCam.setPreviewDisplay(view.getHolder());
            mCam.startPreview();
            mCam.takePicture(null, null, this);
        }
        catch (Exception e)
        {
            System.out.println("Problem taking picture: " + e);
        }
    }

    public void onPictureTaken(byte[] data, Camera cam)
    {
        //   theApp.jpegPictureData(data);  // also my own fcn

        FileOutputStream outStream = null;
        try{
            outStream = new FileOutputStream("/sdcard/Image.jpg");
            outStream.write(data);
            outStream.close();
        } catch (FileNotFoundException e){
            Log.d("CAMERA", e.getMessage());
        } catch (IOException e){
            Log.d("CAMERA", e.getMessage());
        }

        cam.stopPreview();
        cam.release();

        mCam = null;
    }
}
