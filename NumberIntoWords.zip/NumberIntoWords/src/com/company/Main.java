package com.company;

import sun.security.util.Length;


public class Main {

    public static void main(String[] args) {
	// write your code here

        int numbs = 88;

        String[] nums = new String[]{"One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
        String[] leven = new String[]{"Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
        String[] Tens = new String[]{"Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninty"};

        System.out.println("The numer is "  + numbs);
        int chk =numbs%10;
        int chk_hundred =numbs/100;

        if (chk > 0 || chk_hundred > 0) {
            if (numbs >= 1 && numbs <= 9) {
                System.out.println("The numer is " + nums[(numbs) - 1]);

            } else if (numbs >= 11 && numbs <= 19) {
                System.out.println("The numer is " + leven[(numbs % 10) - 1]);

            } else if (numbs >= 21 && numbs <= 99) {

                System.out.println("The numer is " + Tens[(numbs / 10) - 1] + " " + nums[(numbs % 10) - 1]);

            } else if(String.valueOf(numbs).length() == 3 )
            {
                int lastNumb = Integer.valueOf(String.valueOf(numbs).substring(1,3));
                System.out.println("The numer is "  + nums[(numbs/100)-1 ] + " Hundred" +
                        ((lastNumb >= 11 && lastNumb <= 19 ) ? " " + leven[(numbs % 10) - 1] :
                                (((lastNumb / 10) > 0) ?  " " +  Tens[(lastNumb / 10) - 1] : "")
                                        + (((lastNumb % 10) > 0) ? " " + nums[(lastNumb % 10) - 1] : "" )));

            }
            else if(String.valueOf(numbs).length() == 4 || String.valueOf(numbs).length() == 5 )
            {
                int lastNumb = String.valueOf(numbs).length() == 4  ? Integer.valueOf(String.valueOf(numbs).substring(1,4)) : Integer.valueOf(String.valueOf(numbs).substring(0,2));
                int last3Numb = String.valueOf(numbs).length() == 4  ?  Integer.valueOf(String.valueOf(numbs).substring(2,4)) : Integer.valueOf(String.valueOf(numbs).substring(2,5));
                int last2Numb = String.valueOf(numbs).length() == 5   ?  Integer.valueOf(String.valueOf(numbs).substring(3,5)) : 0;
                chk = lastNumb%10;

                System.out.println("The numer is "  + ((String.valueOf(numbs).length() == 4)  ?  nums[(numbs/1000)-1 ]  :((chk > 0)) ? (lastNumb >= 11 && lastNumb <= 19 ) ?  leven[(lastNumb % 10) - 1] : Tens[(lastNumb / 10) - 1] + " " + nums[(lastNumb % 10) - 1] : Tens[(lastNumb/10) -1]) + " Thousand" +
                        ((String.valueOf(numbs).length() == 4) ?  (((lastNumb / 100) > 0) ?  " " +  nums[(lastNumb / 100) - 1] + " Hundred" : "") : (((last3Numb / 100) > 0) ?  " " +  nums[(last3Numb / 100) - 1] + " Hundred" : "")) +
                        ( ( String.valueOf(numbs).length() == 4) ? ((last3Numb >= 11 && last3Numb <= 19 ) ? " " + leven[(numbs % 10) - 1] : (((last3Numb / 10) > 0) ?  " " +  Tens[(last3Numb / 10) - 1] : "") + (((last3Numb % 10) > 0) ? " " + nums[(last3Numb % 10) - 1] : "" ))
                        :  ((last2Numb >= 11 && last2Numb <= 19 ) ? " " + leven[(numbs % 10) - 1] : (((last2Numb / 10) > 0) ?  " " +  Tens[(last2Numb / 10) - 1] : "") + (((last2Numb % 10) > 0) ? " " + nums[(last2Numb % 10) - 1] : "" ))));
            }

        }
        else
        {
            System.out.println("The numer is " + Tens[(numbs/10) -1]);

        }

    }
}
